from pathlib import Path
import yaml
import sys

sys.path.append(str(Path(__file__).parent.parent))

CONFIG_PATH = Path(__file__).resolve().parents[1] / "globals.yml"

with open(CONFIG_PATH, "r") as stream:
    data = yaml.safe_load(stream)


(RESULTS_DIR, DATA_DIR, STATS_DIR, HPARAMS_DIR, KV_DIR) = (
    Path(z)
    for z in [
        data["RESULTS_DIR"],
        data["DATA_DIR"],
        data["STATS_DIR"],
        data["HPARAMS_DIR"],
        data["KV_DIR"],
    ]
)

REMOTE_ROOT_URL = data["REMOTE_ROOT_URL"]
